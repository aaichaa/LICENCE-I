/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author jo
 */
public class Jeu
{
    
    /*
    * Déclaration des attributs d'un jeu (un joueur, un plateau…) et accesseurs.
    */
    
    /**
     * Initialisation du jeu.
     * Création du plateau et d'un joueur.
     */
    public void initJeu(){}
    
    /**
     * Gère les tours de jeu.
     * Fait jouer le joueur et les adversaires tant que le joueur n'est pas neutralisé et n'a pas choisi d'arrêter le jeu
     */
    public void joue()
    {
        /* Code à spécifier */
    }
    
    /**
     * Crée une instance de jeu.
     * Cela crée un joueur, un plateau rempli de bidons et d'adversaires, et lance le jeu (méthode joue())
     * @param nbLig
     * @param nbCol
     */
    public Jeu(int nbLig, int nbCol/*,paramètre, paramètre… */)
    {
        /* Code à spécifier */
    }
}
